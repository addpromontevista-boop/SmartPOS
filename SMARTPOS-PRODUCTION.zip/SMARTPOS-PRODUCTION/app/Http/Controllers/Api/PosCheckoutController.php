<?php

namespace App\Http\Controllers\Api;

use App\Services\DecimalFinancialService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Routing\Controller;

class PosCheckoutController extends Controller
{
    public function __construct(private readonly DecimalFinancialService $math) {}

    public function store(Request $request)
    {
        $validated = $request->validate([
            'client_uuid' => ['required', 'uuid'],
            'store_id' => ['required', 'integer'],
            'terminal_id' => ['required', 'integer'],
            'currency_code' => ['required', 'in:PHP,USD'],
            'payment_method' => ['required', 'in:CASH,CARD,WALLET,BANK_TRANSFER,SPLIT'],
            'amount_tendered' => ['required', 'numeric', 'min:0'],
            'items' => ['required', 'array', 'min:1'],
            'items.*.product_id' => ['required', 'integer'],
            'items.*.quantity' => ['required', 'integer', 'min:1'],
        ]);

        $tenantId = app('current_tenant_id');

        return DB::transaction(function () use ($validated, $tenantId, $request) {
            // Idempotency guard: prevent duplicate submission of same client_uuid
            $existing = DB::table('sales')
                ->where('tenant_id', $tenantId)
                ->where('client_uuid', $validated['client_uuid'])
                ->lockForUpdate()
                ->first();

            if ($existing) {
                return response()->json([
                    'idempotent_replay' => true,
                    'sale' => $existing,
                ], 200);
            }

            // Lock inventory rows and verify stock policy
            foreach ($validated['items'] as $line) {
                $inv = DB::table('inventory')
                    ->where('tenant_id', $tenantId)
                    ->where('store_id', $validated['store_id'])
                    ->where('product_id', $line['product_id'])
                    ->lockForUpdate()
                    ->first();

                if (!$inv || $inv->stock_quantity < $line['quantity']) {
                    abort(422, "Insufficient stock for product ID {$line['product_id']}");
                }
            }

            return response()->json(['status' => 'COMMITTED'], 201);
        });
    }
}
