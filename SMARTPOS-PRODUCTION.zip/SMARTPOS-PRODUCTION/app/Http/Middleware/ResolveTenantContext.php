<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class ResolveTenantContext
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();
        if (!$user) {
            return response()->json(['message' => 'Unauthenticated.'], 401);
        }

        if ($user->role_code === 'SUPERADMIN') {
            $explicitTenant = $request->header('X-Tenant-Id');
            app()->instance('current_tenant_id', $explicitTenant ? (int) $explicitTenant : null);
            return $next($request);
        }

        if (!$user->tenant_id) {
            return response()->json(['message' => 'Tenant context missing.'], 403);
        }

        // Prevent cross-tenant IDOR spoofing
        $headerTenant = $request->header('X-Tenant-Id');
        if ($headerTenant !== null && (int) $headerTenant !== (int) $user->tenant_id) {
            abort(403, 'Cross-tenant access violation blocked.');
        }

        app()->instance('current_tenant_id', (int) $user->tenant_id);
        return $next($request);
    }
}
