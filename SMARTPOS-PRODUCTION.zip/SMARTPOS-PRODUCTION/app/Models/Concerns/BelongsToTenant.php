<?php

namespace App\Models\Concerns;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

trait BelongsToTenant
{
    public static function bootBelongsToTenant(): void
    {
        static::creating(function (Model $model) {
            if (empty($model->tenant_id) && app()->bound('current_tenant_id')) {
                $model->tenant_id = app('current_tenant_id');
            }
        });

        static::addGlobalScope('tenant_isolation', function (Builder $builder) {
            if (app()->bound('current_tenant_id') && app('current_tenant_id') !== null) {
                $builder->where($builder->getModel()->getTable() . '.tenant_id', app('current_tenant_id'));
            }
        });
    }
}
