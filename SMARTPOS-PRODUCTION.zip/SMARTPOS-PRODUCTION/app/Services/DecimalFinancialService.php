<?php

namespace App\Services;

class DecimalFinancialService
{
    /**
     * Exact BC Math decimal operations using scale=4 intermediate precision
     * and half-up rounding to 2 decimal places. Never uses IEEE-754 floats.
     */
    public function add(string $a, string $b): string
    {
        return bcadd($a, $b, 2);
    }

    public function sub(string $a, string $b): string
    {
        return bcsub($a, $b, 2);
    }

    public function mul(string $amount, int|string $qty): string
    {
        return bcmul($amount, (string) $qty, 2);
    }

    public function percentage(string $amount, string $ratePercent): string
    {
        $raw = bcmul($amount, $ratePercent, 6);
        return bcdiv($raw, '100', 2);
    }
}
