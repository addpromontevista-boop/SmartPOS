<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\PosCheckoutController;

Route::middleware(['auth:sanctum', 'tenant'])->group(function () {
    Route::post('/pos/checkout', [PosCheckoutController::class, 'store']);
});
