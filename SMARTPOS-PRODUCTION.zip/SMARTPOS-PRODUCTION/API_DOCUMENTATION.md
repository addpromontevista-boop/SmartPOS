# SMARTPOS REST API Reference

All protected endpoints require user context and enforce strict `tenant_id` isolation.

- `GET /api/bootstrap` — Returns current tenant, stores, products, inventory, open register session, sales, reports, and platform state.
- `POST /api/auth/login` — Authenticates by email/password or switches active demo persona.
- `POST /api/pos/sale` — Commits an online POS sale inside an ACID transaction with idempotency key `clientUuid`.
- `POST /api/pos/sync` — Batch-synchronizes offline IndexedDB queued sales with duplicate prevention and inventory conflict detection.
- `POST /api/pos/refund` — Processes a full or partial refund and optionally restocks inventory.
- `POST /api/inventory/adjust` — Records an auditable `STOCK_IN`, `STOCK_OUT`, or `ADJUSTMENT` movement.
- `POST /api/inventory/transfer` — Transfers stock atomically between two stores/warehouses.
- `POST /api/purchase-orders/:id/receive` — Marks a purchase order received and increments store inventory.
- `POST /api/tests/run` — Executes the live Unit, Feature, Integration, and Security automated test suite.
- `GET /api/export/laravel-zip` — Generates and downloads `SMARTPOS-PRODUCTION.zip`.
