# SMARTPOS Quality Assurance & Automated Testing

SMARTPOS includes an executable automated test runner covering:
1. **Unit Tests**: Safe decimal addition/subtraction, percentage VAT calculation, discount math, and PHP/USD snapshot conversion without floating-point drift.
2. **Feature & Integration Tests**: Idempotent POS checkout (`client_uuid` replay prevention), inventory deduction, negative-stock policy enforcement, and offline sync conflict flagging.
3. **Security & Multi-Tenant Isolation Tests**: Cross-tenant IDOR prevention verifying Tenant #1 cannot read or mutate Tenant #2 products or sales.

Run the suite directly in the **QA & Security Tests** workspace view or via `POST /api/tests/run`.
