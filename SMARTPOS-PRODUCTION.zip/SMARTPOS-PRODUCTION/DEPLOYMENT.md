# SMARTPOS Cloud Deployment Guide

## 1. Target Infrastructure
- **Web Server**: Nginx 1.24+ with PHP 8.3-FPM (document root pointed strictly to `/public`)
- **Database**: Managed MySQL 8.0+ with `innodb_lock_wait_timeout = 50`
- **Cache & Queues**: Redis 7.x with Supervisor worker daemon (`deploy/supervisor-worker.conf`)
- **Storage**: S3-compatible bucket for encrypted database backups and product media

## 2. Scheduler Cron Entry
```cron
* * * * * cd /var/www/smartpos && php artisan schedule:run >> /dev/null 2>&1
```

## 3. Zero-Downtime Rollback Procedure
If a release health check fails at `/api/health`:
1. Switch symlink to previous release directory.
2. Run `php artisan migrate:rollback --step=1` if schema changes were applied.
3. Reload PHP-FPM and restart Supervisor workers: `supervisorctl restart smartpos-worker:*`.
