# SMARTPOS User Guide

## 1. Cashier Workflow
1. **Open Register**: Enter your opening cash float (e.g., `₱5,000.00`) to start a register session.
2. **Ring Up Items**: Tap product tiles, type in the search box, use a USB/Bluetooth barcode scanner, or open the **Camera Barcode Scanner**.
3. **Hold & Resume**: Park an incomplete order with **Hold Order** and restore it anytime.
4. **Checkout & Receipts**: Select `Cash`, `Card`, `Digital Wallet`, or `Split Payment`. Choose **58mm Thermal**, **80mm Thermal**, or **Full Page PDF** to print.
5. **Offline Mode**: If internet connectivity drops, continue ringing up sales. Transactions queue in IndexedDB and automatically sync when connectivity returns.

## 2. Store Manager & Business Owner Workflow
- **Inventory & Ledger**: Add products with PHP/USD prices, record Stock In/Out/Adjustments, transfer stock between stores, and receive Supplier Purchase Orders.
- **Reports**: View segregated **PHP (₱)** and **USD ($)** revenue, COGS, and net profit reports, or toggle an explicit exchange-rate snapshot conversion view.
