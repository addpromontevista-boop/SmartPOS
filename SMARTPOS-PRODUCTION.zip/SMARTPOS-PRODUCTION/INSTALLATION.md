# SMARTPOS Installation Guide

## 1. Web Installation Wizard (9 Steps)
Navigate to the **Installation Wizard** tab in the application or `/install` on a fresh deployment:
1. Welcome & License Verification
2. Server System Requirements Check (PHP 8.3+ / Node 22+ runtime)
3. Extension Check (`PDO`, `BCMath`, `OpenSSL`, `Mbstring`, `JSON`, `Curl`)
4. Database Connection Configuration
5. Database Schema Migration & Foreign Key Setup
6. Application & Multi-Currency Configuration (`PHP` / `USD`)
7. Superadmin Account Provisioning
8. Initial SaaS Subscription Plan Setup (`Starter $9`, `Business $19`, `Premium $39`)
9. Installation Lock Creation (`storage/installed.lock` / `installation_state`)

## 2. Automated CLI Installation (Laravel Production Package)
```bash
composer install --no-dev --optimize-autoloader
cp .env.example .env
php artisan key:generate
php artisan migrate --force
php artisan db:seed --class=ProductionSeeder --force
npm ci && npm run build
php artisan config:cache && php artisan route:cache && php artisan view:cache
```
