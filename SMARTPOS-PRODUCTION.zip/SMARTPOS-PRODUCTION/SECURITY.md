# SMARTPOS Security Architecture

1. **Tenant Isolation & IDOR Protection**: All queries enforce `WHERE tenant_id = :authenticatedTenantId`. Attempting to access or mutate another tenant's product, sale, store, or customer returns HTTP 403/404 and records a security audit event.
2. **Idempotent Financial Transactions**: Every POS sale requires a client-generated `UUIDv4` (`client_uuid`). Retrying an offline sync or double-tapping checkout returns the existing transaction rather than charging or deducting stock twice.
3. **PCI-DSS Safe Payment Recording**: Raw card PANs and CVV codes are never accepted or stored. Card and digital wallet payments record only tokenized provider references (`STRIPE-PI-*`, `PAYPAL-TX-*`).
4. **Webhook Signature Verification**: Incoming payment and subscription webhooks verify HMAC-SHA256 signatures and deduplicate webhook event IDs.
5. **Audit Trail**: Sensitive operations (register open/close, cash movements, stock adjustments, refunds, voids, plan changes, backups) write immutable records to `audit_logs`.
