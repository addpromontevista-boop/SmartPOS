<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('currencies', function (Blueprint $table) {
            $table->string('code', 3)->primary();
            $table->string('name', 64);
            $table->string('symbol', 8);
            $table->unsignedTinyInteger('decimal_precision')->default(2);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        Schema::create('exchange_rates', function (Blueprint $table) {
            $table->id();
            $table->string('base_currency', 3);
            $table->string('target_currency', 3);
            $table->decimal('rate', 15, 6);
            $table->timestamp('effective_at');
            $table->index(['base_currency', 'target_currency', 'effective_at']);
        });

        Schema::create('subscription_plans', function (Blueprint $table) {
            $table->id();
            $table->string('code', 32)->unique();
            $table->string('name', 100);
            $table->decimal('monthly_price_usd', 15, 2);
            $table->decimal('annual_price_usd', 15, 2);
            $table->decimal('monthly_price_php', 15, 2);
            $table->decimal('annual_price_php', 15, 2);
            $table->unsignedInteger('max_stores')->default(1);
            $table->unsignedInteger('max_users')->default(3);
            $table->json('features_json');
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        Schema::create('tenants', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique();
            $table->string('name', 150);
            $table->string('slug', 150)->unique();
            $table->string('tax_id_tin', 64)->nullable();
            $table->string('primary_currency', 3)->default('PHP');
            $table->boolean('allow_negative_stock')->default(false);
            $table->decimal('default_tax_rate', 5, 2)->default(12.00);
            $table->string('plan_code', 32)->default('STARTER');
            $table->string('status', 24)->default('ACTIVE');
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::create('stores', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('code', 32);
            $table->string('name', 150);
            $table->string('default_currency', 3)->default('PHP');
            $table->decimal('tax_rate', 5, 2)->default(12.00);
            $table->boolean('is_warehouse')->default(false);
            $table->unique(['tenant_id', 'code']);
            $table->timestamps();
        });

        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('sku', 64);
            $table->string('barcode', 64);
            $table->string('name', 180);
            $table->decimal('cost_price', 15, 2);
            $table->decimal('selling_price', 15, 2);
            $table->decimal('wholesale_price', 15, 2)->default(0);
            $table->decimal('cost_price_usd', 15, 2)->default(0);
            $table->decimal('selling_price_usd', 15, 2)->default(0);
            $table->date('expiration_date')->nullable();
            $table->unique(['tenant_id', 'sku']);
            $table->unique(['tenant_id', 'barcode']);
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::create('inventory', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('store_id')->constrained('stores')->cascadeOnDelete();
            $table->foreignId('product_id')->constrained('products')->cascadeOnDelete();
            $table->integer('stock_quantity')->default(0);
            $table->integer('min_stock_level')->default(10);
            $table->integer('reorder_level')->default(20);
            $table->unique(['tenant_id', 'store_id', 'product_id']);
            $table->timestamps();
        });

        Schema::create('sales', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->foreignId('store_id')->constrained('stores');
            $table->string('transaction_number', 64);
            $table->uuid('client_uuid');
            $table->string('currency_code', 3);
            $table->decimal('exchange_rate_snapshot', 15, 6);
            $table->decimal('subtotal', 15, 2);
            $table->decimal('discount_total', 15, 2)->default(0);
            $table->decimal('tax_total', 15, 2)->default(0);
            $table->decimal('service_charge', 15, 2)->default(0);
            $table->decimal('grand_total', 15, 2);
            $table->decimal('cogs_total', 15, 2);
            $table->decimal('profit_total', 15, 2);
            $table->string('payment_method', 32);
            $table->string('status', 24)->default('COMPLETED');
            $table->unique(['tenant_id', 'transaction_number']);
            $table->unique(['tenant_id', 'client_uuid']);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('sales');
        Schema::dropIfExists('inventory');
        Schema::dropIfExists('products');
        Schema::dropIfExists('stores');
        Schema::dropIfExists('tenants');
        Schema::dropIfExists('subscription_plans');
        Schema::dropIfExists('exchange_rates');
        Schema::dropIfExists('currencies');
    }
};
