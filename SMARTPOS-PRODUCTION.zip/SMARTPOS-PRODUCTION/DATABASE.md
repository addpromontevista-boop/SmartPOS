# SMARTPOS Database Architecture & Entity-Relationship Documentation

## 1. Multi-Tenant Isolation Rules
Every tenant-owned table includes `tenant_id` indexed as the leading column in composite unique constraints (e.g. `UNIQUE(tenant_id, sku)`, `UNIQUE(tenant_id, barcode)`, `UNIQUE(tenant_id, transaction_number)`, `UNIQUE(tenant_id, client_uuid)`).

## 2. Core Entity-Relationship Diagram (ERD)
```
[tenants] 1 ─── * [stores] 1 ─── * [terminals]
    │                │
    ├── * [users]    ├── * [inventory] * ─── 1 [products]
    │                ├── * [inventory_movements] (Immutable Stock Ledger)
    │                ├── * [cash_register_sessions] 1 ─── * [cash_movements]
    │                └── * [sales] 1 ─── * [sale_items]
    │                         └── 1 ─── * [refunds]
    ├── * [customers]
    ├── * [suppliers] 1 ─── * [purchase_orders]
    ├── * [subscription_invoices]
    └── * [offline_sync_logs]
```

## 3. Financial Column Specifications
All monetary columns use `DECIMAL(15,2)` (or scaled integer minor units) paired with explicit `currency_code` (`PHP` or `USD`) and `exchange_rate_snapshot`.
