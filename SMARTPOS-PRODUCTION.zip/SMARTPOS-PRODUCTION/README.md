# SMARTPOS — Multi-Tenant Mobile POS & Inventory SaaS (v1.0.0)

SMARTPOS is a production-oriented Multi-Tenant Mobile Point of Sale (POS) and Inventory Management SaaS platform supporting **PHP (₱)** and **USD ($)** currencies, **offline-first PWA checkout**, **auditable stock ledgers**, and **granular role-based access control**.

## Key Capabilities
1. **Multi-Tenant SaaS Isolation**: Shared database architecture with mandatory `tenant_id` scoping across all tenant entities, IDOR prevention middleware, and Superadmin platform oversight.
2. **Offline-First Mobile POS PWA**: Continues selling during internet outages using IndexedDB local catalog cache and `UUIDv4` idempotent sales queues with explicit conflict detection.
3. **Safe Decimal Multi-Currency Engine**: Zero floating-point arithmetic; supports `PHP (₱)` and `USD ($)` with historical exchange-rate snapshots and segregated currency reporting.
4. **Complete Inventory & Stock Ledger**: Products, variants, SKUs, barcodes, stock-in, stock-out, adjustments, inter-store transfers, purchase orders, low-stock alerts, and expiration tracking.
5. **Thermal Receipt & Cash Register Management**: Supports 58mm and 80mm thermal receipts, opening floats, cash deposits/withdrawals, and closing variance reconciliation.

## Demo Credentials
| Role | Email | Password | PIN | Scope |
| :--- | :--- | :--- | :--- | :--- |
| **Superadmin** | `superadmin@smartpos.io` | `Admin@12345` | `9999` | Global Platform Administration |
| **Business Owner** | `owner@auroracoffee.ph` | `Owner@12345` | `1111` | Aurora Specialty Coffee (Tenant #1) |
| **Store Manager** | `manager@auroracoffee.ph` | `Manager@12345` | `2222` | Makati Flagship Store (`MKT-01`) |
| **Cashier** | `cashier@auroracoffee.ph` | `Cashier@12345` | `3333` | POS Terminal `POS-MKT-01` |
| **Tenant #2 Owner** | `founder@pacifichorizon.io` | `Owner@12345` | `4444` | Pacific Horizon Electronics (USD Tenant) |
